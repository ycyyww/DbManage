package com.example.interfaces_better;

/**
 * File: interfaces
 * User: YcY
 * Date: 14-7-29
 * Time: ����9:33
 * Describetion:
 */
public interface Service {
    void method1();
    void method2();
}
