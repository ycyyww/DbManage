package com.example.interfaces_better;

/**
 * File: interfaces
 * User: YcY
 * Date: 14-7-29
 * Time: ����9:34
 * Describetion:
 */
public interface ServiceFactory {
    Service getService();
}
